"""
多模态向量存储

实现支持文本和图像的向量存储系统，使用多模态embedding模型。
"""

import os
import json
import pickle
import hashlib
from typing import List, Dict, Any, Optional, Tuple, Union
import logging

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False

from ..processors.smart_chunker import DocumentChunk
from ..config import VECTOR_STORE_CONFIG
from .metadata_store import MetadataStore

logger = logging.getLogger(__name__)


class MultimodalVectorStore:
    """
    多模态向量存储
    
    功能：
    1. 文本和图像的向量化
    2. 高效的向量索引和搜索
    3. 元数据管理
    4. 持久化存储
    """
    
    def __init__(
        self,
        storage_path: str,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        初始化向量存储
        
        Args:
            storage_path: 存储路径
            config: 配置参数
        """
        self.storage_path = storage_path
        self.config = config or VECTOR_STORE_CONFIG
        
        # 创建存储目录
        os.makedirs(storage_path, exist_ok=True)
        
        # 初始化组件
        self._init_embeddings()
        self._init_indexes()
        self._init_metadata_store()
        
        # 加载已有数据
        self._load_existing_data()
    
    def _init_embeddings(self):
        """初始化embedding模型"""
        self.text_embedder = None
        self.image_embedder = None
        
        # 初始化文本embedding模型
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                # 使用多语言模型
                self.text_embedder = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
                logger.info("文本embedding模型初始化成功")
            except Exception as e:
                logger.error(f"文本embedding模型初始化失败: {str(e)}")
        
        # 初始化图像embedding模型
        try:
            # 这里可以集成CLIP或其他多模态模型
            # 暂时使用文本模型处理图像的OCR文本
            self.image_embedder = self.text_embedder
            if self.image_embedder:
                logger.info("图像embedding模型初始化成功")
        except Exception as e:
            logger.error(f"图像embedding模型初始化失败: {str(e)}")
    
    def _init_indexes(self):
        """初始化向量索引"""
        self.text_index = None
        self.image_index = None
        
        if not FAISS_AVAILABLE:
            logger.error("FAISS未安装，无法创建向量索引")
            return
        
        # 获取embedding维度 - 动态检测
        embedding_dim = self.config.get('embedding_dim', 384)  # MiniLM默认维度

        # 如果有text_embedder，动态获取实际维度
        if self.text_embedder:
            try:
                test_embedding = self.text_embedder.encode(["test"], convert_to_numpy=True)
                embedding_dim = test_embedding.shape[1]
                logger.info(f"检测到embedding维度: {embedding_dim}")
            except Exception as e:
                logger.warning(f"无法检测embedding维度，使用默认值: {embedding_dim}")
        else:
            logger.warning(f"使用默认embedding维度: {embedding_dim}")
        
        # 创建文本索引
        index_type = self.config.get('index_type', 'HNSW')
        if index_type == 'Flat':
            self.text_index = faiss.IndexFlatIP(embedding_dim)
        elif index_type == 'IVF':
            nlist = self.config.get('nlist', 100)
            quantizer = faiss.IndexFlatIP(embedding_dim)
            self.text_index = faiss.IndexIVFFlat(quantizer, embedding_dim, nlist)
        elif index_type == 'HNSW':
            self.text_index = faiss.IndexHNSWFlat(embedding_dim, self.config.get('m', 16))
            self.text_index.hnsw.efConstruction = self.config.get('ef_construction', 200)
            self.text_index.hnsw.efSearch = self.config.get('ef_search', 100)
        
        # 创建图像索引（使用相同配置）
        if index_type == 'Flat':
            self.image_index = faiss.IndexFlatIP(embedding_dim)
        elif index_type == 'IVF':
            nlist = self.config.get('nlist', 100)
            quantizer = faiss.IndexFlatIP(embedding_dim)
            self.image_index = faiss.IndexIVFFlat(quantizer, embedding_dim, nlist)
        elif index_type == 'HNSW':
            self.image_index = faiss.IndexHNSWFlat(embedding_dim, self.config.get('m', 16))
            self.image_index.hnsw.efConstruction = self.config.get('ef_construction', 200)
            self.image_index.hnsw.efSearch = self.config.get('ef_search', 100)
        
        logger.info(f"向量索引初始化成功: {index_type}")
    
    def _init_metadata_store(self):
        """初始化元数据存储"""
        metadata_path = os.path.join(self.storage_path, "metadata")
        self.metadata_store = MetadataStore(metadata_path)
    
    def _load_existing_data(self):
        """加载已有数据"""
        try:
            # 加载文本索引
            text_index_path = os.path.join(self.storage_path, "text_index.faiss")
            if os.path.exists(text_index_path) and FAISS_AVAILABLE:
                self.text_index = faiss.read_index(text_index_path)
                logger.info("加载已有文本索引")
            
            # 加载图像索引
            image_index_path = os.path.join(self.storage_path, "image_index.faiss")
            if os.path.exists(image_index_path) and FAISS_AVAILABLE:
                self.image_index = faiss.read_index(image_index_path)
                logger.info("加载已有图像索引")
        
        except Exception as e:
            logger.warning(f"加载已有数据失败: {str(e)}")
    
    def add_chunks(self, chunks: List[DocumentChunk], source: str):
        """
        添加文档块到向量存储
        
        Args:
            chunks: 文档块列表
            source: 文档来源
        """
        logger.info(f"添加{len(chunks)}个文档块到向量存储")
        
        text_chunks = []
        image_chunks = []
        
        # 分类文档块
        for chunk in chunks:
            if chunk.chunk_type in ['text', 'table']:
                text_chunks.append(chunk)
            elif chunk.chunk_type == 'image':
                image_chunks.append(chunk)
        
        # 处理文本块
        if text_chunks:
            self._add_text_chunks(text_chunks, source)
        
        # 处理图像块
        if image_chunks:
            self._add_image_chunks(image_chunks, source)
        
        # 保存索引
        self._save_indexes()
        
        logger.info(f"向量存储添加完成: {len(text_chunks)}个文本块, {len(image_chunks)}个图像块")
    
    def _add_text_chunks(self, chunks: List[DocumentChunk], source: str):
        """添加文本块"""
        if not self.text_embedder or not FAISS_AVAILABLE:
            logger.error("文本embedding模型或FAISS未可用")
            return
        
        # 提取文本内容
        texts = [chunk.content for chunk in chunks]
        
        # 生成embeddings
        try:
            embeddings = self.text_embedder.encode(texts, convert_to_numpy=True)
            
            # 标准化向量
            embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
            
            # 添加到索引
            start_id = self.text_index.ntotal
            self.text_index.add(embeddings.astype(np.float32))
            
            # 保存元数据
            for i, chunk in enumerate(chunks):
                chunk_id = start_id + i
                metadata = chunk.metadata.copy()
                metadata.update({
                    'chunk_id': chunk_id,
                    'source': source,
                    'chunk_type': chunk.chunk_type,
                    'content': chunk.content,
                    'token_count': chunk.token_count,
                    'index_type': 'text'
                })
                self.metadata_store.add_metadata(str(chunk_id), metadata)
        
        except Exception as e:
            logger.error(f"添加文本块失败: {str(e)}")
    
    def _add_image_chunks(self, chunks: List[DocumentChunk], source: str):
        """添加图像块（优化存储结构）"""
        if not self.image_embedder or not FAISS_AVAILABLE:
            logger.error("图像embedding模型或FAISS未可用")
            return

        # 提取图像文本内容（包括LLM生成的描述和OCR文本）
        texts = []
        for chunk in chunks:
            # 构建完整的图像内容描述用于embedding
            text_content = chunk.content

            # 如果内容为空，使用图像路径作为备选
            if not text_content.strip():
                text_content = f"图像文件: {chunk.metadata.get('image_path', 'unknown')}"

            # 添加图像路径信息以增强检索效果
            image_path = chunk.metadata.get('image_path', '')
            if image_path:
                filename = os.path.basename(image_path)
                text_content = f"图像文件名: {filename}\n图像内容: {text_content}"

            texts.append(text_content)

        # 生成embeddings
        try:
            embeddings = self.image_embedder.encode(texts, convert_to_numpy=True)

            # 标准化向量
            embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)

            # 添加到索引
            start_id = self.image_index.ntotal
            self.image_index.add(embeddings.astype(np.float32))

            # 保存增强的元数据
            for i, chunk in enumerate(chunks):
                chunk_id = start_id + i
                metadata = chunk.metadata.copy()

                # 分离LLM描述和OCR文本
                content = chunk.content
                llm_description = ""
                ocr_text = ""

                # 尝试分离LLM描述和OCR文本
                if "补充OCR文字内容：" in content:
                    parts = content.split("补充OCR文字内容：", 1)
                    llm_description = parts[0].strip()
                    ocr_text = parts[1].strip() if len(parts) > 1 else ""
                else:
                    llm_description = content

                metadata.update({
                    'chunk_id': chunk_id,
                    'source': source,
                    'chunk_type': chunk.chunk_type,
                    'content': chunk.content,  # 完整内容
                    'llm_description': llm_description,  # LLM生成的描述
                    'ocr_text': ocr_text,  # OCR识别的文本
                    'token_count': chunk.token_count,
                    'index_type': 'image',
                    'embedding_text': texts[i]  # 用于embedding的文本
                })
                self.metadata_store.add_metadata(f"img_{chunk_id}", metadata)

            logger.info(f"成功添加{len(chunks)}个图像块到向量存储")

        except Exception as e:
            logger.error(f"添加图像块失败: {str(e)}")
    
    def search(
        self,
        query: str,
        top_k: int = 10,
        search_type: str = 'both',  # 'text', 'image', 'both'
        score_threshold: float = 0.0
    ) -> List[Dict[str, Any]]:
        """
        搜索相关文档块
        
        Args:
            query: 查询文本
            top_k: 返回结果数量
            search_type: 搜索类型
            score_threshold: 分数阈值
            
        Returns:
            搜索结果列表
        """
        results = []
        text_results = []
        image_results = []

        if search_type in ['text', 'both']:
            text_results = self._search_text(query, top_k, score_threshold)

        if search_type in ['image', 'both']:
            image_results = self._search_images(query, top_k, score_threshold)

        # 标准化分数以确保公平比较
        if text_results and image_results:
            # 分别标准化文本和图像结果的分数
            text_results = self._normalize_scores(text_results)
            image_results = self._normalize_scores(image_results)

        # 合并结果
        results.extend(text_results)
        results.extend(image_results)

        # 按分数排序
        results.sort(key=lambda x: x['score'], reverse=True)

        # 返回top_k结果
        return results[:top_k]
    
    def _search_text(self, query: str, top_k: int, score_threshold: float) -> List[Dict[str, Any]]:
        """搜索文本"""
        if not self.text_embedder or not FAISS_AVAILABLE or self.text_index.ntotal == 0:
            return []
        
        try:
            # 生成查询向量
            query_embedding = self.text_embedder.encode([query], convert_to_numpy=True)
            query_embedding = query_embedding / np.linalg.norm(query_embedding, axis=1, keepdims=True)
            
            # 搜索
            scores, indices = self.text_index.search(query_embedding.astype(np.float32), top_k)
            
            results = []
            for score, idx in zip(scores[0], indices[0]):
                if idx != -1 and score >= score_threshold:
                    metadata = self.metadata_store.get_metadata(str(idx))
                    if metadata:
                        result = metadata.copy()
                        result['score'] = float(score)
                        results.append(result)
            
            return results
        
        except Exception as e:
            logger.error(f"文本搜索失败: {str(e)}")
            return []
    
    def _search_images(self, query: str, top_k: int, score_threshold: float) -> List[Dict[str, Any]]:
        """搜索图像"""
        if not self.image_embedder or not FAISS_AVAILABLE or self.image_index.ntotal == 0:
            return []
        
        try:
            # 生成查询向量
            query_embedding = self.image_embedder.encode([query], convert_to_numpy=True)
            query_embedding = query_embedding / np.linalg.norm(query_embedding, axis=1, keepdims=True)
            
            # 搜索
            scores, indices = self.image_index.search(query_embedding.astype(np.float32), top_k)
            
            results = []
            for score, idx in zip(scores[0], indices[0]):
                if idx != -1 and score >= score_threshold:
                    metadata = self.metadata_store.get_metadata(f"img_{idx}")
                    if metadata:
                        result = metadata.copy()
                        result['score'] = float(score)
                        results.append(result)
            
            return results
        
        except Exception as e:
            logger.error(f"图像搜索失败: {str(e)}")
            return []

    def _normalize_scores(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        标准化分数到[0,1]范围

        Args:
            results: 搜索结果列表

        Returns:
            标准化后的结果列表
        """
        if not results:
            return results

        scores = [result['score'] for result in results]
        min_score = min(scores)
        max_score = max(scores)

        # 避免除零错误
        if max_score == min_score:
            for result in results:
                result['score'] = 1.0
        else:
            for result in results:
                normalized_score = (result['score'] - min_score) / (max_score - min_score)
                result['score'] = normalized_score

        return results

    def _save_indexes(self):
        """保存索引"""
        if not FAISS_AVAILABLE:
            return
        
        try:
            # 保存文本索引
            if self.text_index and self.text_index.ntotal > 0:
                text_index_path = os.path.join(self.storage_path, "text_index.faiss")
                faiss.write_index(self.text_index, text_index_path)
            
            # 保存图像索引
            if self.image_index and self.image_index.ntotal > 0:
                image_index_path = os.path.join(self.storage_path, "image_index.faiss")
                faiss.write_index(self.image_index, image_index_path)
            
            logger.info("向量索引保存成功")
        
        except Exception as e:
            logger.error(f"保存索引失败: {str(e)}")
    
    def get_info(self) -> Dict[str, Any]:
        """获取存储信息"""
        info = {
            'storage_path': self.storage_path,
            'text_count': self.text_index.ntotal if self.text_index else 0,
            'image_count': self.image_index.ntotal if self.image_index else 0,
            'total_count': 0,
            'config': self.config
        }
        
        info['total_count'] = info['text_count'] + info['image_count']
        return info
    
    def clear(self):
        """清空存储"""
        try:
            # 重新初始化索引
            self._init_indexes()
            
            # 清空元数据
            self.metadata_store.clear()
            
            # 删除索引文件
            text_index_path = os.path.join(self.storage_path, "text_index.faiss")
            image_index_path = os.path.join(self.storage_path, "image_index.faiss")
            
            if os.path.exists(text_index_path):
                os.remove(text_index_path)
            if os.path.exists(image_index_path):
                os.remove(image_index_path)
            
            logger.info("向量存储已清空")
        
        except Exception as e:
            logger.error(f"清空存储失败: {str(e)}")

    def get_source_info(self, source: str) -> Optional[Dict[str, Any]]:
        """
        获取指定来源的文档信息

        Args:
            source: 文档来源

        Returns:
            文档信息字典，如果不存在返回None
        """
        try:
            # 查询元数据存储
            metadata_list = self.metadata_store.get_metadata_by_source(source)
            if not metadata_list:
                return None

            # 统计信息
            total_chunks = len(metadata_list)
            text_chunks = sum(1 for m in metadata_list if m.get('chunk_type') == 'text')
            image_chunks = sum(1 for m in metadata_list if m.get('chunk_type') == 'image')

            return {
                'source': source,
                'total_chunks': total_chunks,
                'text_chunks': text_chunks,
                'image_chunks': image_chunks,
                'exists': True
            }

        except Exception as e:
            logger.error(f"获取来源信息失败: {str(e)}")
            return None

    def delete_by_source(self, source: str):
        """
        删除指定来源的所有数据

        Args:
            source: 文档来源
        """
        try:
            # 删除元数据
            self.metadata_store.delete_by_source(source)

            # 注意：FAISS索引不支持单独删除，需要重建
            # 这里我们标记需要重建索引
            logger.warning(f"已删除来源 {source} 的元数据，建议重建向量索引以完全清除数据")

        except Exception as e:
            logger.error(f"删除来源数据失败: {str(e)}")

    def rebuild_index_for_source(self, source: str):
        """
        为指定来源重建索引（实际上是重建整个索引但排除指定来源）

        Args:
            source: 要排除的文档来源
        """
        try:
            # 获取所有非指定来源的数据
            all_metadata = self.metadata_store.get_all_metadata()
            remaining_metadata = [m for m in all_metadata if m.get('source') != source]

            if not remaining_metadata:
                # 如果没有剩余数据，直接清空
                self.clear()
                return

            # 重新初始化索引
            self._init_indexes()

            # 按类型分组重建
            text_chunks = []
            image_chunks = []

            for metadata in remaining_metadata:
                chunk_type = metadata.get('chunk_type', 'text')
                content = metadata.get('content', '')

                chunk_data = {
                    'content': content,
                    'chunk_type': chunk_type,
                    'metadata': metadata
                }

                if chunk_type == 'image':
                    image_chunks.append(chunk_data)
                else:
                    text_chunks.append(chunk_data)

            # 重建文本索引
            if text_chunks:
                texts = [chunk['content'] for chunk in text_chunks]
                text_embeddings = self.text_model.encode(texts, show_progress_bar=True)

                for i, embedding in enumerate(text_embeddings):
                    self.text_index.add(np.array([embedding], dtype=np.float32))

                # 保存索引
                text_index_path = os.path.join(self.storage_path, "text_index.faiss")
                faiss.write_index(self.text_index, text_index_path)

            # 重建图像索引
            if image_chunks:
                image_texts = [chunk['content'] for chunk in image_chunks]
                image_embeddings = self.image_model.encode(image_texts, show_progress_bar=True)

                for i, embedding in enumerate(image_embeddings):
                    self.image_index.add(np.array([embedding], dtype=np.float32))

                # 保存索引
                image_index_path = os.path.join(self.storage_path, "image_index.faiss")
                faiss.write_index(self.image_index, image_index_path)

            logger.info(f"索引重建完成，排除来源: {source}")

        except Exception as e:
            logger.error(f"重建索引失败: {str(e)}")
