"""
元数据存储

管理文档块的元数据信息。
"""

import os
import json
import sqlite3
from typing import Dict, Any, Optional, List
import logging

logger = logging.getLogger(__name__)


class MetadataStore:
    """
    元数据存储
    
    使用SQLite数据库存储文档块的元数据信息。
    """
    
    def __init__(self, storage_path: str):
        """
        初始化元数据存储
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)
        
        self.db_path = os.path.join(storage_path, "metadata.db")
        self._init_database()
    
    def _init_database(self):
        """初始化数据库"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 创建元数据表
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS metadata (
                        id TEXT PRIMARY KEY,
                        chunk_id INTEGER,
                        source TEXT,
                        chunk_type TEXT,
                        content TEXT,
                        token_count INTEGER,
                        index_type TEXT,
                        page_num INTEGER,
                        chunk_index INTEGER,
                        metadata_json TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # 创建索引
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_source ON metadata(source)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_chunk_type ON metadata(chunk_type)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_page_num ON metadata(page_num)')
                
                conn.commit()
                logger.info("元数据数据库初始化成功")
        
        except Exception as e:
            logger.error(f"数据库初始化失败: {str(e)}")
    
    def add_metadata(self, chunk_id: str, metadata: Dict[str, Any]):
        """
        添加元数据
        
        Args:
            chunk_id: 块ID
            metadata: 元数据字典
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 提取主要字段
                source = metadata.get('source', '')
                chunk_type = metadata.get('chunk_type', '')
                content = metadata.get('content', '')
                token_count = metadata.get('token_count', 0)
                index_type = metadata.get('index_type', '')
                page_num = metadata.get('page_num', 0)
                chunk_index = metadata.get('chunk_index', 0)
                
                # 将完整元数据序列化为JSON
                metadata_json = json.dumps(metadata, ensure_ascii=False)
                
                # 插入数据
                cursor.execute('''
                    INSERT OR REPLACE INTO metadata 
                    (id, chunk_id, source, chunk_type, content, token_count, 
                     index_type, page_num, chunk_index, metadata_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    chunk_id,
                    metadata.get('chunk_id', 0),
                    source,
                    chunk_type,
                    content,
                    token_count,
                    index_type,
                    page_num,
                    chunk_index,
                    metadata_json
                ))
                
                conn.commit()
        
        except Exception as e:
            logger.error(f"添加元数据失败: {str(e)}")
    
    def get_metadata(self, chunk_id: str) -> Optional[Dict[str, Any]]:
        """
        获取元数据
        
        Args:
            chunk_id: 块ID
            
        Returns:
            元数据字典
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT metadata_json FROM metadata WHERE id = ?', (chunk_id,))
                result = cursor.fetchone()
                
                if result:
                    return json.loads(result[0])
                else:
                    return None
        
        except Exception as e:
            logger.error(f"获取元数据失败: {str(e)}")
            return None
    
    def get_metadata_by_source(self, source: str) -> List[Dict[str, Any]]:
        """
        根据来源获取元数据
        
        Args:
            source: 文档来源
            
        Returns:
            元数据列表
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT metadata_json FROM metadata WHERE source = ?', (source,))
                results = cursor.fetchall()
                
                metadata_list = []
                for result in results:
                    metadata_list.append(json.loads(result[0]))
                
                return metadata_list
        
        except Exception as e:
            logger.error(f"根据来源获取元数据失败: {str(e)}")
            return []
    
    def get_metadata_by_type(self, chunk_type: str) -> List[Dict[str, Any]]:
        """
        根据类型获取元数据
        
        Args:
            chunk_type: 块类型
            
        Returns:
            元数据列表
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT metadata_json FROM metadata WHERE chunk_type = ?', (chunk_type,))
                results = cursor.fetchall()
                
                metadata_list = []
                for result in results:
                    metadata_list.append(json.loads(result[0]))
                
                return metadata_list
        
        except Exception as e:
            logger.error(f"根据类型获取元数据失败: {str(e)}")
            return []
    
    def search_content(self, query: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        搜索内容
        
        Args:
            query: 搜索查询
            limit: 结果限制
            
        Returns:
            搜索结果列表
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 使用FTS进行全文搜索（如果支持）
                cursor.execute('''
                    SELECT metadata_json FROM metadata 
                    WHERE content LIKE ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                ''', (f'%{query}%', limit))
                
                results = cursor.fetchall()
                
                metadata_list = []
                for result in results:
                    metadata_list.append(json.loads(result[0]))
                
                return metadata_list
        
        except Exception as e:
            logger.error(f"搜索内容失败: {str(e)}")
            return []
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 总数统计
                cursor.execute('SELECT COUNT(*) FROM metadata')
                total_count = cursor.fetchone()[0]
                
                # 按类型统计
                cursor.execute('''
                    SELECT chunk_type, COUNT(*) 
                    FROM metadata 
                    GROUP BY chunk_type
                ''')
                type_counts = dict(cursor.fetchall())
                
                # 按来源统计
                cursor.execute('''
                    SELECT source, COUNT(*) 
                    FROM metadata 
                    GROUP BY source
                ''')
                source_counts = dict(cursor.fetchall())
                
                # Token统计
                cursor.execute('SELECT SUM(token_count) FROM metadata')
                total_tokens = cursor.fetchone()[0] or 0
                
                return {
                    'total_count': total_count,
                    'type_counts': type_counts,
                    'source_counts': source_counts,
                    'total_tokens': total_tokens
                }
        
        except Exception as e:
            logger.error(f"获取统计信息失败: {str(e)}")
            return {}
    
    def delete_by_source(self, source: str):
        """
        根据来源删除元数据
        
        Args:
            source: 文档来源
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('DELETE FROM metadata WHERE source = ?', (source,))
                deleted_count = cursor.rowcount
                
                conn.commit()
                logger.info(f"删除了{deleted_count}条元数据记录")
        
        except Exception as e:
            logger.error(f"删除元数据失败: {str(e)}")
    
    def clear(self):
        """清空所有元数据"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('DELETE FROM metadata')
                conn.commit()
                
                logger.info("元数据已清空")
        
        except Exception as e:
            logger.error(f"清空元数据失败: {str(e)}")

    def get_metadata_by_source(self, source: str) -> List[Dict[str, Any]]:
        """
        根据来源获取元数据

        Args:
            source: 文档来源

        Returns:
            元数据列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                SELECT content, chunk_type, metadata_json
                FROM metadata
                WHERE source = ?
                ORDER BY page_num, chunk_index
            ''', (source,))

            results = []
            for row in cursor.fetchall():
                content, chunk_type, metadata_json = row
                metadata = json.loads(metadata_json)
                metadata['content'] = content
                metadata['chunk_type'] = chunk_type
                results.append(metadata)

            conn.close()
            return results

        except Exception as e:
            logger.error(f"根据来源获取元数据失败: {str(e)}")
            return []

    def get_all_metadata(self) -> List[Dict[str, Any]]:
        """
        获取所有元数据

        Returns:
            所有元数据列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                SELECT content, chunk_type, metadata_json
                FROM metadata
                ORDER BY page_num, chunk_index
            ''')

            results = []
            for row in cursor.fetchall():
                content, chunk_type, metadata_json = row
                metadata = json.loads(metadata_json)
                metadata['content'] = content
                metadata['chunk_type'] = chunk_type
                results.append(metadata)

            conn.close()
            return results

        except Exception as e:
            logger.error(f"获取所有元数据失败: {str(e)}")
            return []
    
    def close(self):
        """关闭数据库连接"""
        # SQLite连接在with语句中自动关闭，这里不需要特殊处理
        pass
