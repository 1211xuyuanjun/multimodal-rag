"""
多模态预处理器

对多模态内容进行预处理，包括文本清理、图片处理、特征提取等。
"""

import re
import os
from typing import List, Dict, Any, Optional, Tuple
import logging

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

from .smart_chunker import DocumentChunk

logger = logging.getLogger(__name__)


class MultimodalPreprocessor:
    """
    多模态预处理器
    
    功能：
    1. 文本清理和标准化
    2. 图片预处理和特征提取
    3. 表格格式化
    4. 多模态内容融合
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化预处理器
        
        Args:
            config: 配置参数
        """
        self.config = config or {}
        
        # 文本清理配置
        self.remove_extra_whitespace = self.config.get('remove_extra_whitespace', True)
        self.normalize_unicode = self.config.get('normalize_unicode', True)
        self.remove_special_chars = self.config.get('remove_special_chars', False)
        
        # 图片处理配置
        self.image_resize = self.config.get('image_resize', True)
        self.image_max_size = self.config.get('image_max_size', (1024, 1024))
        self.image_quality = self.config.get('image_quality', 85)
    
    def preprocess_chunks(self, chunks: List[DocumentChunk]) -> List[DocumentChunk]:
        """
        预处理文档块列表
        
        Args:
            chunks: 原始文档块列表
            
        Returns:
            预处理后的文档块列表
        """
        logger.info(f"开始预处理{len(chunks)}个文档块")
        
        processed_chunks = []
        
        for chunk in chunks:
            try:
                processed_chunk = self.preprocess_chunk(chunk)
                if processed_chunk:
                    processed_chunks.append(processed_chunk)
            except Exception as e:
                logger.warning(f"预处理块失败: {str(e)}")
                # 保留原始块
                processed_chunks.append(chunk)
        
        logger.info(f"预处理完成，保留{len(processed_chunks)}个块")
        return processed_chunks
    
    def preprocess_chunk(self, chunk: DocumentChunk) -> Optional[DocumentChunk]:
        """
        预处理单个文档块
        
        Args:
            chunk: 原始文档块
            
        Returns:
            预处理后的文档块
        """
        if chunk.chunk_type == 'text':
            return self._preprocess_text_chunk(chunk)
        elif chunk.chunk_type == 'table':
            return self._preprocess_table_chunk(chunk)
        elif chunk.chunk_type == 'image':
            return self._preprocess_image_chunk(chunk)
        else:
            return chunk
    
    def _preprocess_text_chunk(self, chunk: DocumentChunk) -> DocumentChunk:
        """
        预处理文本块
        
        Args:
            chunk: 文本块
            
        Returns:
            预处理后的文本块
        """
        content = chunk.content
        
        # 文本清理
        content = self._clean_text(content)
        
        # 提取文本特征
        text_features = self._extract_text_features(content)
        
        # 更新元数据
        metadata = chunk.metadata.copy()
        metadata.update({
            'text_features': text_features,
            'preprocessed': True
        })
        
        return DocumentChunk(content, chunk.chunk_type, metadata, chunk.token_count)
    
    def _preprocess_table_chunk(self, chunk: DocumentChunk) -> DocumentChunk:
        """
        预处理表格块
        
        Args:
            chunk: 表格块
            
        Returns:
            预处理后的表格块
        """
        content = chunk.content
        
        # 表格格式化
        content = self._format_table(content)
        
        # 提取表格特征
        table_features = self._extract_table_features(content)
        
        # 更新元数据
        metadata = chunk.metadata.copy()
        metadata.update({
            'table_features': table_features,
            'preprocessed': True
        })
        
        return DocumentChunk(content, chunk.chunk_type, metadata, chunk.token_count)
    
    def _preprocess_image_chunk(self, chunk: DocumentChunk) -> DocumentChunk:
        """
        预处理图片块
        
        Args:
            chunk: 图片块
            
        Returns:
            预处理后的图片块
        """
        content = chunk.content
        metadata = chunk.metadata.copy()
        
        # 处理图片文件
        if 'image_path' in metadata and os.path.exists(metadata['image_path']):
            processed_image_path = self._process_image(metadata['image_path'])
            if processed_image_path:
                metadata['processed_image_path'] = processed_image_path
        
        # 提取图片特征
        image_features = self._extract_image_features(metadata)
        metadata['image_features'] = image_features
        metadata['preprocessed'] = True
        
        return DocumentChunk(content, chunk.chunk_type, metadata, chunk.token_count)
    
    def _clean_text(self, text: str) -> str:
        """
        清理文本内容
        
        Args:
            text: 原始文本
            
        Returns:
            清理后的文本
        """
        if not text:
            return ""
        
        # Unicode标准化
        if self.normalize_unicode:
            import unicodedata
            text = unicodedata.normalize('NFKC', text)
        
        # 移除多余的空白字符
        if self.remove_extra_whitespace:
            text = re.sub(r'\s+', ' ', text)
            text = text.strip()
        
        # 移除特殊字符（可选）
        if self.remove_special_chars:
            text = re.sub(r'[^\w\s\u4e00-\u9fff.,!?;:()[\]{}"\'-]', '', text)
        
        # 修复常见的OCR错误
        text = self._fix_ocr_errors(text)
        
        return text
    
    def _fix_ocr_errors(self, text: str) -> str:
        """
        修复常见的OCR错误
        
        Args:
            text: 原始文本
            
        Returns:
            修复后的文本
        """
        # 常见OCR错误映射
        ocr_fixes = {
            r'\b0\b': 'O',  # 数字0误识别为字母O
            r'\bl\b': 'I',  # 小写l误识别为大写I
            r'rn': 'm',     # rn误识别为m
            r'vv': 'w',     # vv误识别为w
        }
        
        for pattern, replacement in ocr_fixes.items():
            text = re.sub(pattern, replacement, text)
        
        return text
    
    def _format_table(self, table_content: str) -> str:
        """
        格式化表格内容
        
        Args:
            table_content: 原始表格内容
            
        Returns:
            格式化后的表格内容
        """
        if not table_content:
            return ""
        
        lines = table_content.split('\n')
        formatted_lines = []
        
        for line in lines:
            if line.strip():
                # 清理表格行
                line = self._clean_text(line)
                
                # 确保表格格式正确
                if not line.startswith('|'):
                    line = '|' + line
                if not line.endswith('|'):
                    line = line + '|'
                
                formatted_lines.append(line)
        
        return '\n'.join(formatted_lines)
    
    def _extract_text_features(self, text: str) -> Dict[str, Any]:
        """
        提取文本特征
        
        Args:
            text: 文本内容
            
        Returns:
            文本特征字典
        """
        features = {
            'length': len(text),
            'word_count': len(text.split()),
            'sentence_count': len(re.findall(r'[.!?。！？]+', text)),
            'has_chinese': bool(re.search(r'[\u4e00-\u9fff]', text)),
            'has_english': bool(re.search(r'[a-zA-Z]', text)),
            'has_numbers': bool(re.search(r'\d', text)),
            'has_punctuation': bool(re.search(r'[.,!?;:()[\]{}"\'-]', text)),
        }
        
        return features
    
    def _extract_table_features(self, table_content: str) -> Dict[str, Any]:
        """
        提取表格特征
        
        Args:
            table_content: 表格内容
            
        Returns:
            表格特征字典
        """
        lines = [line for line in table_content.split('\n') if line.strip()]
        
        features = {
            'row_count': len(lines),
            'column_count': 0,
            'has_header': False,
            'cell_count': 0
        }
        
        if lines:
            # 估算列数（基于第一行）
            first_row = lines[0]
            features['column_count'] = len(first_row.split('|')) - 2  # 减去首尾的空字符串
            
            # 检查是否有表头（简单启发式）
            if len(lines) > 1:
                first_row_cells = first_row.split('|')[1:-1]  # 去掉首尾
                second_row_cells = lines[1].split('|')[1:-1]
                
                # 如果第二行是分隔符，则第一行是表头
                if all(re.match(r'^[-\s]*$', cell.strip()) for cell in second_row_cells):
                    features['has_header'] = True
            
            # 计算总单元格数
            for line in lines:
                cells = line.split('|')[1:-1]  # 去掉首尾
                features['cell_count'] += len([cell for cell in cells if cell.strip()])
        
        return features
    
    def _process_image(self, image_path: str) -> Optional[str]:
        """
        处理图片文件
        
        Args:
            image_path: 图片路径
            
        Returns:
            处理后的图片路径
        """
        if not PIL_AVAILABLE:
            logger.warning("PIL未安装，跳过图片处理")
            return image_path
        
        try:
            with Image.open(image_path) as img:
                # 转换为RGB模式
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # 调整尺寸
                if self.image_resize:
                    img.thumbnail(self.image_max_size, Image.Resampling.LANCZOS)
                
                # 保存处理后的图片
                processed_path = image_path.replace('.png', '_processed.jpg')
                img.save(processed_path, 'JPEG', quality=self.image_quality)
                
                return processed_path
        
        except Exception as e:
            logger.error(f"图片处理失败: {str(e)}")
            return image_path
    
    def _extract_image_features(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        提取图片特征
        
        Args:
            metadata: 图片元数据
            
        Returns:
            图片特征字典
        """
        features = {
            'width': metadata.get('width', 0),
            'height': metadata.get('height', 0),
            'has_ocr': metadata.get('has_ocr', False),
            'aspect_ratio': 0,
            'size_category': 'unknown'
        }
        
        # 计算长宽比
        if features['width'] > 0 and features['height'] > 0:
            features['aspect_ratio'] = features['width'] / features['height']
            
            # 图片尺寸分类
            total_pixels = features['width'] * features['height']
            if total_pixels < 50000:  # 小于50k像素
                features['size_category'] = 'small'
            elif total_pixels < 500000:  # 小于500k像素
                features['size_category'] = 'medium'
            else:
                features['size_category'] = 'large'
        
        return features
