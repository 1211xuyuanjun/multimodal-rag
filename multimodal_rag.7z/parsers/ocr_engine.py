"""
OCR引擎

支持多种OCR引擎的文字识别功能。
"""

import os
from typing import List, Dict, Any, Optional, Tuple
import logging

try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False

try:
    import pytesseract
    from PIL import Image
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False

from ..config import OCR_CONFIG

logger = logging.getLogger(__name__)


class OCRResult:
    """OCR识别结果"""
    
    def __init__(self, text: str, confidence: float, bbox: Optional[Tuple[int, int, int, int]] = None):
        self.text = text
        self.confidence = confidence
        self.bbox = bbox  # (x1, y1, x2, y2)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'text': self.text,
            'confidence': self.confidence,
            'bbox': self.bbox
        }


class OCREngine:
    """
    OCR引擎
    
    支持多种OCR引擎：
    1. EasyOCR - 支持多语言，准确率高
    2. Tesseract - 传统OCR引擎，速度快
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化OCR引擎
        
        Args:
            config: 配置参数
        """
        self.config = config or OCR_CONFIG
        self.engine = self.config.get('engine', 'easyocr')
        self.languages = self.config.get('languages', ['ch_sim', 'en'])
        self.confidence_threshold = self.config.get('confidence_threshold', 0.5)
        
        # 初始化OCR引擎
        self._init_engine()

    def _check_gpu_availability(self) -> bool:
        """检查GPU是否可用"""
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            # 如果没有torch，尝试其他方法检测GPU
            try:
                import subprocess
                result = subprocess.run(['nvidia-smi'], capture_output=True, text=True)
                return result.returncode == 0
            except (subprocess.SubprocessError, FileNotFoundError):
                return False

    def _init_engine(self):
        """初始化OCR引擎"""
        if self.engine == 'easyocr':
            if EASYOCR_AVAILABLE:
                try:
                    # 处理GPU配置
                    gpu_config = self.config.get('use_gpu', 'auto')
                    gpu_available = self._check_gpu_availability()

                    if gpu_config == 'auto':
                        use_gpu = gpu_available
                    elif gpu_config is True:
                        use_gpu = True
                        if not gpu_available:
                            logger.warning("配置要求使用GPU但GPU不可用，回退到CPU模式")
                            use_gpu = False
                    else:
                        use_gpu = False

                    self.reader = easyocr.Reader(self.languages, gpu=use_gpu)

                    if use_gpu:
                        logger.info("EasyOCR引擎初始化成功 (GPU模式)")
                    else:
                        logger.info("EasyOCR引擎初始化成功 (CPU模式)")

                except Exception as e:
                    logger.error(f"EasyOCR初始化失败: {str(e)}")
                    self.reader = None
            else:
                logger.error("EasyOCR未安装")
                self.reader = None
        
        elif self.engine == 'tesseract':
            if TESSERACT_AVAILABLE:
                # 检查Tesseract是否可用
                try:
                    pytesseract.get_tesseract_version()
                    logger.info("Tesseract引擎初始化成功")
                except Exception as e:
                    logger.error(f"Tesseract初始化失败: {str(e)}")
            else:
                logger.error("Tesseract未安装")
        
        else:
            logger.error(f"不支持的OCR引擎: {self.engine}")
    
    def extract_text(self, image_path: str) -> str:
        """
        从图片中提取文字
        
        Args:
            image_path: 图片路径
            
        Returns:
            提取的文字
        """
        if not os.path.exists(image_path):
            logger.error(f"图片文件不存在: {image_path}")
            return ""
        
        try:
            if self.engine == 'easyocr':
                return self._extract_with_easyocr(image_path)
            elif self.engine == 'tesseract':
                return self._extract_with_tesseract(image_path)
            else:
                logger.error(f"不支持的OCR引擎: {self.engine}")
                return ""
        
        except Exception as e:
            logger.error(f"OCR文字提取失败: {str(e)}")
            return ""
    
    def extract_text_with_details(self, image_path: str) -> List[OCRResult]:
        """
        从图片中提取文字（包含详细信息）
        
        Args:
            image_path: 图片路径
            
        Returns:
            OCR结果列表
        """
        if not os.path.exists(image_path):
            logger.error(f"图片文件不存在: {image_path}")
            return []
        
        try:
            if self.engine == 'easyocr':
                return self._extract_details_with_easyocr(image_path)
            elif self.engine == 'tesseract':
                return self._extract_details_with_tesseract(image_path)
            else:
                logger.error(f"不支持的OCR引擎: {self.engine}")
                return []
        
        except Exception as e:
            logger.error(f"OCR详细提取失败: {str(e)}")
            return []
    
    def _extract_with_easyocr(self, image_path: str) -> str:
        """使用EasyOCR提取文字"""
        if not EASYOCR_AVAILABLE or self.reader is None:
            return ""
        
        try:
            results = self.reader.readtext(image_path)
            
            # 过滤低置信度结果
            filtered_texts = []
            for (bbox, text, confidence) in results:
                if confidence >= self.confidence_threshold:
                    filtered_texts.append(text)
            
            return ' '.join(filtered_texts)
        
        except Exception as e:
            logger.error(f"EasyOCR提取失败: {str(e)}")
            return ""
    
    def _extract_details_with_easyocr(self, image_path: str) -> List[OCRResult]:
        """使用EasyOCR提取详细信息"""
        if not EASYOCR_AVAILABLE or self.reader is None:
            return []
        
        try:
            results = self.reader.readtext(image_path)
            
            ocr_results = []
            for (bbox, text, confidence) in results:
                if confidence >= self.confidence_threshold:
                    # 转换bbox格式
                    x1 = int(min([point[0] for point in bbox]))
                    y1 = int(min([point[1] for point in bbox]))
                    x2 = int(max([point[0] for point in bbox]))
                    y2 = int(max([point[1] for point in bbox]))
                    
                    ocr_result = OCRResult(
                        text=text,
                        confidence=confidence,
                        bbox=(x1, y1, x2, y2)
                    )
                    ocr_results.append(ocr_result)
            
            return ocr_results
        
        except Exception as e:
            logger.error(f"EasyOCR详细提取失败: {str(e)}")
            return []
    
    def _extract_with_tesseract(self, image_path: str) -> str:
        """使用Tesseract提取文字"""
        if not TESSERACT_AVAILABLE:
            return ""
        
        try:
            # 设置语言
            lang = 'chi_sim+eng' if 'ch_sim' in self.languages else 'eng'
            
            # 打开图片
            image = Image.open(image_path)
            
            # 提取文字
            text = pytesseract.image_to_string(image, lang=lang)
            
            return text.strip()
        
        except Exception as e:
            logger.error(f"Tesseract提取失败: {str(e)}")
            return ""
    
    def _extract_details_with_tesseract(self, image_path: str) -> List[OCRResult]:
        """使用Tesseract提取详细信息"""
        if not TESSERACT_AVAILABLE:
            return []
        
        try:
            # 设置语言
            lang = 'chi_sim+eng' if 'ch_sim' in self.languages else 'eng'
            
            # 打开图片
            image = Image.open(image_path)
            
            # 提取详细信息
            data = pytesseract.image_to_data(image, lang=lang, output_type=pytesseract.Output.DICT)
            
            ocr_results = []
            n_boxes = len(data['text'])
            
            for i in range(n_boxes):
                text = data['text'][i].strip()
                confidence = float(data['conf'][i]) / 100.0  # 转换为0-1范围
                
                if text and confidence >= self.confidence_threshold:
                    x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                    bbox = (x, y, x + w, y + h)
                    
                    ocr_result = OCRResult(
                        text=text,
                        confidence=confidence,
                        bbox=bbox
                    )
                    ocr_results.append(ocr_result)
            
            return ocr_results
        
        except Exception as e:
            logger.error(f"Tesseract详细提取失败: {str(e)}")
            return []
    
    def is_available(self) -> bool:
        """检查OCR引擎是否可用"""
        if self.engine == 'easyocr':
            return EASYOCR_AVAILABLE and self.reader is not None
        elif self.engine == 'tesseract':
            return TESSERACT_AVAILABLE
        else:
            return False
