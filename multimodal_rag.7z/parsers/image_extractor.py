"""
图片提取器

从PDF文档中提取图片，支持多种图片格式和尺寸过滤。
"""

import os
import io
import hashlib
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import logging

try:
    import fitz  # PyMuPDF
    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# 图片提取配置
IMAGE_EXTRACTOR_CONFIG = {
    "image_min_size": (50, 50),  # 最小图片尺寸
    "image_max_size": (2048, 2048),  # 最大图片尺寸
}

logger = logging.getLogger(__name__)


class ImageExtractor:
    """
    图片提取器
    
    从PDF文档中提取图片，支持：
    1. 多种图片格式 (JPEG, PNG, etc.)
    2. 图片尺寸过滤
    3. 图片质量检查
    4. 图片去重
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化图片提取器
        
        Args:
            config: 配置参数
        """
        self.config = config or IMAGE_EXTRACTOR_CONFIG
        self.min_size = self.config.get('image_min_size', (50, 50))
        self.max_size = self.config.get('image_max_size', (2048, 2048))
        
        # 检查依赖
        if not PYMUPDF_AVAILABLE:
            logger.warning("PyMuPDF未安装，图片提取功能受限")
        if not PIL_AVAILABLE:
            logger.warning("PIL未安装，图片处理功能受限")
    
    def extract_from_pdf(self, pdf_path: str, output_dir: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        从PDF中提取图片
        
        Args:
            pdf_path: PDF文件路径
            output_dir: 输出目录，如果为None则使用临时目录
            
        Returns:
            提取的图片信息列表
        """
        if not PYMUPDF_AVAILABLE:
            logger.error("PyMuPDF未安装，无法提取图片")
            return []
        
        # 设置输出目录
        if output_dir is None:
            output_dir = os.path.join(os.path.dirname(pdf_path), "extracted_images")
        os.makedirs(output_dir, exist_ok=True)
        
        extracted_images = []
        
        try:
            # 打开PDF文档
            pdf_document = fitz.open(pdf_path)
            
            for page_num in range(len(pdf_document)):
                page = pdf_document[page_num]
                
                # 获取页面中的图片
                image_list = page.get_images()
                
                for img_index, img in enumerate(image_list):
                    try:
                        # 提取图片数据
                        img_data = self._extract_image_data(pdf_document, img, page_num, img_index)
                        
                        if img_data:
                            # 保存图片
                            img_path = self._save_image(img_data, output_dir, page_num, img_index)
                            
                            if img_path:
                                # 创建图片信息
                                img_info = {
                                    'image_path': img_path,
                                    'page_num': page_num + 1,
                                    'image_index': img_index,
                                    'width': img_data['width'],
                                    'height': img_data['height'],
                                    'format': img_data['format'],
                                    'size_bytes': len(img_data['data']),
                                    'bbox': img_data.get('bbox'),
                                    'hash': img_data['hash']
                                }
                                
                                extracted_images.append(img_info)
                    
                    except Exception as e:
                        logger.warning(f"提取第{page_num+1}页第{img_index}张图片失败: {str(e)}")
                        continue
            
            pdf_document.close()
            
        except Exception as e:
            logger.error(f"PDF图片提取失败: {str(e)}")
            return []
        
        # 去重
        extracted_images = self._deduplicate_images(extracted_images)
        
        logger.info(f"从PDF中提取了{len(extracted_images)}张图片")
        return extracted_images
    
    def _extract_image_data(self, pdf_doc, img, page_num: int, img_index: int) -> Optional[Dict[str, Any]]:
        """
        提取图片数据
        
        Args:
            pdf_doc: PDF文档对象
            img: 图片对象
            page_num: 页码
            img_index: 图片索引
            
        Returns:
            图片数据字典
        """
        try:
            # 获取图片引用
            xref = img[0]
            pix = fitz.Pixmap(pdf_doc, xref)
            
            # 检查图片格式
            if pix.n - pix.alpha < 4:  # 确保不是CMYK格式
                # 获取图片尺寸
                width, height = pix.width, pix.height
                
                # 检查尺寸是否符合要求
                if not self._is_valid_size(width, height):
                    pix = None
                    return None
                
                # 转换为RGB格式
                if pix.n != 4:  # 不是RGB+Alpha格式
                    pix = fitz.Pixmap(fitz.csRGB, pix)
                
                # 获取图片数据
                img_data = pix.tobytes("png")
                img_hash = hashlib.md5(img_data).hexdigest()
                
                result = {
                    'data': img_data,
                    'width': width,
                    'height': height,
                    'format': 'PNG',
                    'hash': img_hash,
                    'bbox': None  # 可以添加边界框信息
                }
                
                pix = None
                return result
            
            else:
                pix = None
                return None
                
        except Exception as e:
            logger.warning(f"提取图片数据失败: {str(e)}")
            return None
    
    def _is_valid_size(self, width: int, height: int) -> bool:
        """
        检查图片尺寸是否有效
        
        Args:
            width: 图片宽度
            height: 图片高度
            
        Returns:
            是否有效
        """
        # 检查最小尺寸
        if width < self.min_size[0] or height < self.min_size[1]:
            return False
        
        # 检查最大尺寸
        if width > self.max_size[0] or height > self.max_size[1]:
            return False
        
        # 检查长宽比（避免过于细长的图片）
        aspect_ratio = max(width, height) / min(width, height)
        if aspect_ratio > 10:  # 长宽比超过10:1
            return False
        
        return True
    
    def _save_image(self, img_data: Dict[str, Any], output_dir: str, page_num: int, img_index: int) -> Optional[str]:
        """
        保存图片到文件
        
        Args:
            img_data: 图片数据
            output_dir: 输出目录
            page_num: 页码
            img_index: 图片索引
            
        Returns:
            保存的文件路径
        """
        try:
            # 生成文件名
            filename = f"page_{page_num+1}_img_{img_index}_{img_data['hash'][:8]}.png"
            file_path = os.path.join(output_dir, filename)
            
            # 保存图片
            with open(file_path, 'wb') as f:
                f.write(img_data['data'])
            
            return file_path
            
        except Exception as e:
            logger.error(f"保存图片失败: {str(e)}")
            return None
    
    def _deduplicate_images(self, images: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        去除重复图片
        
        Args:
            images: 图片列表
            
        Returns:
            去重后的图片列表
        """
        seen_hashes = set()
        unique_images = []
        
        for img in images:
            img_hash = img['hash']
            if img_hash not in seen_hashes:
                seen_hashes.add(img_hash)
                unique_images.append(img)
        
        if len(unique_images) < len(images):
            logger.info(f"去重后保留{len(unique_images)}张图片（原{len(images)}张）")
        
        return unique_images
    
    def resize_image(self, image_path: str, max_size: Tuple[int, int] = (1024, 1024)) -> Optional[str]:
        """
        调整图片尺寸
        
        Args:
            image_path: 图片路径
            max_size: 最大尺寸
            
        Returns:
            调整后的图片路径
        """
        if not PIL_AVAILABLE:
            logger.warning("PIL未安装，无法调整图片尺寸")
            return image_path
        
        try:
            with Image.open(image_path) as img:
                # 计算新尺寸
                img.thumbnail(max_size, Image.Resampling.LANCZOS)
                
                # 保存调整后的图片
                resized_path = image_path.replace('.png', '_resized.png')
                img.save(resized_path, 'PNG')
                
                return resized_path
                
        except Exception as e:
            logger.error(f"调整图片尺寸失败: {str(e)}")
            return image_path
