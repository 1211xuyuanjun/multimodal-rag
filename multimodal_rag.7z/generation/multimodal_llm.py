"""
多模态LLM

集成多模态大语言模型进行内容理解和生成。
"""

import os
import sys
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
import logging

# 添加Qwen-Agent到路径
sys.path.append(str(Path(__file__).parent.parent.parent / "Qwen-Agent"))

from qwen_agent.llm.base import BaseChatModel
from qwen_agent.llm.schema import Message, USER, ASSISTANT, SYSTEM

from ..config import MULTIMODAL_MODEL_CONFIG

logger = logging.getLogger(__name__)


class MultimodalLLM:
    """
    多模态LLM包装器
    
    功能：
    1. 文本理解和生成
    2. 图像理解和描述
    3. 多模态内容融合
    4. 结构化输出生成
    """
    
    def __init__(
        self,
        llm: Optional[BaseChatModel] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        初始化多模态LLM
        
        Args:
            llm: 基础语言模型
            config: 配置参数
        """
        self.llm = llm
        self.config = config or MULTIMODAL_MODEL_CONFIG
        
        # 模型配置
        self.vision_model = self.config.get('vision_model', 'qwen-vl-plus')
        self.text_model = self.config.get('text_model', 'qwen-plus')
    
    def generate_text(
        self,
        prompt: str,
        context: Optional[str] = None,
        max_length: int = 1000,
        temperature: float = 0.1
    ) -> str:
        """
        生成文本
        
        Args:
            prompt: 提示文本
            context: 上下文信息
            max_length: 最大长度
            temperature: 温度参数
            
        Returns:
            生成的文本
        """
        if not self.llm:
            logger.error("LLM未初始化")
            return ""
        
        try:
            # 构建完整提示
            full_prompt = prompt
            if context:
                full_prompt = f"上下文信息：\n{context}\n\n{prompt}"
            
            messages = [Message(USER, full_prompt)]
            
            # 生成回答
            response = None
            for response in self.llm.chat(messages):
                continue
            
            if response and response[-1].role == ASSISTANT:
                return response[-1].content.strip()
            else:
                return ""
        
        except Exception as e:
            logger.error(f"文本生成失败: {str(e)}")
            return ""
    
    def analyze_image(
        self,
        image_path: str,
        question: Optional[str] = None
    ) -> str:
        """
        分析图像
        
        Args:
            image_path: 图像路径
            question: 关于图像的问题
            
        Returns:
            图像分析结果
        """
        if not os.path.exists(image_path):
            logger.error(f"图像文件不存在: {image_path}")
            return ""
        
        try:
            # 构建图像分析提示
            if question:
                prompt = f"请分析这张图片并回答问题：{question}"
            else:
                prompt = "请详细描述这张图片的内容，包括主要对象、场景、文字等信息。"
            
            # 这里应该调用多模态模型，暂时返回占位符
            # 在实际实现中，需要集成具体的多模态模型API
            return self._placeholder_image_analysis(image_path, prompt)
        
        except Exception as e:
            logger.error(f"图像分析失败: {str(e)}")
            return ""
    
    def _placeholder_image_analysis(self, image_path: str, prompt: str) -> str:
        """图像分析占位符实现"""
        # 尝试使用qwen-vl进行图像分析
        try:
            return self._analyze_image_with_qwen_vl(image_path, prompt)
        except Exception as e:
            logger.warning(f"多模态分析失败，使用基础分析: {str(e)}")
            return self._basic_image_analysis(image_path)

    def _analyze_image_with_qwen_vl(self, image_path: str, prompt: str) -> str:
        """使用Qwen-VL进行图像分析"""
        try:
            from qwen_agent.llm.schema import ContentItem, Message, USER, ASSISTANT

            # 构建多模态消息
            content = [
                ContentItem(image=image_path),
                ContentItem(text=prompt)
            ]

            messages = [Message(USER, content)]

            # 调用多模态LLM
            response = None
            for response in self.llm.chat(messages):
                continue

            if response and response[-1].role == ASSISTANT:
                return response[-1].content.strip()
            else:
                return self._basic_image_analysis(image_path)

        except Exception as e:
            logger.error(f"Qwen-VL图像分析失败: {str(e)}")
            return self._basic_image_analysis(image_path)

    def _basic_image_analysis(self, image_path: str) -> str:
        """基础图像分析"""
        try:
            from PIL import Image
            import os

            # 获取图像基本信息
            with Image.open(image_path) as img:
                width, height = img.size
                mode = img.mode

            filename = os.path.basename(image_path)

            # 基于文件名和尺寸推断内容类型
            if 'chart' in filename.lower() or 'graph' in filename.lower():
                return f"这是一个图表或图形，尺寸为{width}x{height}像素，可能包含数据可视化、统计图表或示意图。"
            elif 'table' in filename.lower():
                return f"这是一个表格图像，尺寸为{width}x{height}像素，可能包含结构化的数据或信息。"
            elif 'diagram' in filename.lower() or 'flow' in filename.lower():
                return f"这是一个示意图或流程图，尺寸为{width}x{height}像素，可能展示了系统架构、流程或概念关系。"
            elif width > height * 2:  # 宽图，可能是流程图或时间线
                return f"这是一个宽幅图像（{width}x{height}像素），可能是流程图、时间线或横向布局的内容。"
            elif height > width * 2:  # 高图，可能是列表或垂直布局
                return f"这是一个高长图像（{width}x{height}像素），可能包含列表、垂直布局的内容或长文本。"
            else:
                return f"这是一个图像（{width}x{height}像素），可能包含文本、图表、照片或其他视觉内容。"

        except Exception as e:
            logger.error(f"基础图像分析失败: {str(e)}")
            return "这是一张图像，内容需要进一步分析。"
    
    def summarize_content(
        self,
        content: str,
        summary_type: str = "general",
        max_length: int = 500
    ) -> str:
        """
        内容总结
        
        Args:
            content: 要总结的内容
            summary_type: 总结类型 ('general', 'key_points', 'abstract')
            max_length: 最大长度
            
        Returns:
            总结结果
        """
        if not content.strip():
            return ""
        
        # 根据总结类型构建提示
        if summary_type == "key_points":
            prompt = f"请提取以下内容的关键要点，以条目形式列出：\n\n{content}"
        elif summary_type == "abstract":
            prompt = f"请为以下内容写一个简洁的摘要：\n\n{content}"
        else:
            prompt = f"请总结以下内容的主要信息：\n\n{content}"
        
        return self.generate_text(prompt, max_length=max_length)
    
    def extract_key_information(
        self,
        content: str,
        info_type: str = "all"
    ) -> Dict[str, Any]:
        """
        提取关键信息
        
        Args:
            content: 内容文本
            info_type: 信息类型 ('all', 'entities', 'numbers', 'dates')
            
        Returns:
            提取的信息字典
        """
        if not content.strip():
            return {}
        
        try:
            if info_type == "entities":
                prompt = f"请从以下内容中提取人名、地名、机构名等实体：\n\n{content}"
            elif info_type == "numbers":
                prompt = f"请从以下内容中提取所有数字、统计数据和量化信息：\n\n{content}"
            elif info_type == "dates":
                prompt = f"请从以下内容中提取所有日期、时间信息：\n\n{content}"
            else:
                prompt = f"请从以下内容中提取关键信息，包括实体、数字、日期等：\n\n{content}"
            
            result = self.generate_text(prompt, max_length=300)
            
            return {
                'type': info_type,
                'extracted_info': result,
                'source_length': len(content)
            }
        
        except Exception as e:
            logger.error(f"信息提取失败: {str(e)}")
            return {}
    
    def generate_structured_answer(
        self,
        question: str,
        context_chunks: List[Dict[str, Any]],
        answer_format: str = "detailed"
    ) -> Dict[str, Any]:
        """
        生成结构化回答
        
        Args:
            question: 问题
            context_chunks: 上下文块列表
            answer_format: 回答格式 ('detailed', 'brief', 'bullet_points')
            
        Returns:
            结构化回答字典
        """
        if not context_chunks:
            return {
                'answer': "抱歉，没有找到相关信息来回答您的问题。",
                'sources': [],
                'confidence': 0.0
            }
        
        try:
            # 构建上下文
            context_parts = []
            sources = []
            
            for i, chunk in enumerate(context_chunks):
                content = chunk.get('content', '')
                source = chunk.get('source', 'unknown')
                page_num = chunk.get('page_num', 0)
                chunk_type = chunk.get('chunk_type', 'text')
                
                if content.strip():
                    context_parts.append(f"[参考资料{i+1}] {content}")
                    sources.append({
                        'index': i + 1,
                        'source': source,
                        'page_num': page_num,
                        'chunk_type': chunk_type,
                        'score': chunk.get('score', 0.0)
                    })
            
            context = "\n\n".join(context_parts)
            
            # 根据格式构建提示
            if answer_format == "brief":
                format_instruction = "请简洁地回答问题，控制在100字以内。"
            elif answer_format == "bullet_points":
                format_instruction = "请以要点形式回答问题，使用项目符号列出关键信息。"
            else:
                format_instruction = "请详细回答问题，提供充分的解释和说明。"
            
            prompt = f"""请基于以下参考资料回答问题。

参考资料：
{context}

问题：{question}

回答要求：
1. {format_instruction}
2. 必须基于参考资料的内容回答，不要编造信息
3. 如果参考资料中没有足够信息，请明确说明
4. 回答要完整、连贯，避免片段式的回答
5. 可以引用参考资料编号来支持你的回答
6. 如果是数据相关问题，请列出具体的数据、图表、实验结果等
7. 如果是概念性问题，请提供清晰的定义和解释

请提供完整的回答："""

            answer = self.generate_text(prompt, max_length=1500)
            
            # 计算置信度（基于检索分数）
            scores = [chunk.get('score', 0.0) for chunk in context_chunks]
            confidence = sum(scores) / len(scores) if scores else 0.0
            
            return {
                'answer': answer,
                'sources': sources,
                'confidence': min(confidence, 1.0),
                'context_length': len(context),
                'answer_format': answer_format
            }
        
        except Exception as e:
            logger.error(f"生成结构化回答失败: {str(e)}")
            return {
                'answer': f"生成回答时出现错误: {str(e)}",
                'sources': [],
                'confidence': 0.0
            }
    
    def evaluate_answer_quality(
        self,
        question: str,
        answer: str,
        context: str
    ) -> Dict[str, Any]:
        """
        评估回答质量
        
        Args:
            question: 问题
            answer: 回答
            context: 上下文
            
        Returns:
            质量评估结果
        """
        try:
            prompt = f"""请评估以下回答的质量：

问题：{question}
回答：{answer}
参考上下文：{context}

请从以下维度评分（1-5分）：
1. 相关性：回答是否直接回应了问题
2. 准确性：回答是否基于提供的上下文
3. 完整性：回答是否充分全面
4. 清晰性：回答是否表达清晰

请给出各维度的分数和总体评价。"""

            evaluation = self.generate_text(prompt, max_length=300)
            
            return {
                'evaluation': evaluation,
                'timestamp': None  # 可以添加时间戳
            }
        
        except Exception as e:
            logger.error(f"回答质量评估失败: {str(e)}")
            return {'evaluation': '评估失败', 'error': str(e)}
