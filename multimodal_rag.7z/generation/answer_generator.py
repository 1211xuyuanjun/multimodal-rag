"""
答案生成器

集成多模态LLM进行内容总结和最终回答生成。
"""

import re
from typing import List, Dict, Any, Optional
import logging

from .multimodal_llm import MultimodalLLM
from ..config import GENERATION_CONFIG

logger = logging.getLogger(__name__)


class AnswerGenerator:
    """
    答案生成器
    
    功能：
    1. 基于检索结果生成回答
    2. 多模态内容融合
    3. 引用和来源管理
    4. 回答质量控制
    """
    
    def __init__(
        self,
        llm=None,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        初始化答案生成器
        
        Args:
            llm: 语言模型
            config: 配置参数
        """
        self.config = config or GENERATION_CONFIG
        self.multimodal_llm = MultimodalLLM(llm, config)
        
        # 生成配置
        self.max_context_length = self.config.get('max_context_length', 8000)
        self.answer_max_length = self.config.get('answer_max_length', 1000)
        self.include_sources = self.config.get('include_sources', True)
        self.citation_format = self.config.get('citation_format', 'markdown')
    
    def generate_answer(
        self,
        question: str,
        retrieved_chunks: List[Dict[str, Any]],
        answer_format: str = "detailed"
    ) -> str:
        """
        生成最终答案
        
        Args:
            question: 用户问题
            retrieved_chunks: 检索到的文档块
            answer_format: 回答格式
            
        Returns:
            生成的答案
        """
        logger.info(f"开始生成答案: {question[:50]}...")
        
        if not retrieved_chunks:
            return "抱歉，没有找到相关信息来回答您的问题。请尝试重新表述您的问题或提供更多上下文。"
        
        try:
            # 预处理检索结果
            processed_chunks = self._preprocess_chunks(retrieved_chunks)
            
            # 生成结构化回答
            structured_answer = self.multimodal_llm.generate_structured_answer(
                question=question,
                context_chunks=processed_chunks,
                answer_format=answer_format
            )
            
            # 格式化最终答案
            final_answer = self._format_final_answer(
                structured_answer,
                question,
                processed_chunks
            )
            
            logger.info("答案生成完成")
            return final_answer
        
        except Exception as e:
            logger.error(f"答案生成失败: {str(e)}")
            return f"生成答案时出现错误，请稍后重试。错误信息: {str(e)}"
    
    def _preprocess_chunks(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        预处理检索块
        
        Args:
            chunks: 原始检索块
            
        Returns:
            预处理后的块
        """
        processed_chunks = []
        total_length = 0
        
        # 按相关性分数排序，确保最相关的内容优先
        sorted_chunks = sorted(chunks, key=lambda x: x.get('score', 0), reverse=True)
        min_chunk_length = self.config.get('min_chunk_length', 50)

        for chunk in sorted_chunks:
            content = chunk.get('content', '').strip()
            if not content or len(content) < min_chunk_length:
                continue

            # 检查长度限制
            if total_length + len(content) > self.max_context_length:
                # 智能截断，尝试保留完整句子
                remaining_length = self.max_context_length - total_length
                if remaining_length > 200:  # 至少保留200字符才有意义
                    truncated_content = self._smart_truncate(content, remaining_length)
                    if truncated_content:
                        chunk = chunk.copy()
                        chunk['content'] = truncated_content
                        processed_chunks.append(chunk)
                break

            processed_chunks.append(chunk)
            total_length += len(content)

        logger.info(f"预处理完成: 保留{len(processed_chunks)}个块，总长度{total_length}")
        return processed_chunks

    def _smart_truncate(self, content: str, max_length: int) -> str:
        """
        智能截断文本，尽量保留完整句子

        Args:
            content: 原始内容
            max_length: 最大长度

        Returns:
            截断后的内容
        """
        if len(content) <= max_length:
            return content

        # 尝试在句号、问号、感叹号处截断
        truncated = content[:max_length]

        # 查找最后一个句子结束符
        for delimiter in ['. ', '。', '? ', '？', '! ', '！']:
            last_pos = truncated.rfind(delimiter)
            if last_pos > max_length * 0.7:  # 至少保留70%的内容
                return truncated[:last_pos + 1]

        # 如果没有找到合适的截断点，在最后一个空格处截断
        last_space = truncated.rfind(' ')
        if last_space > max_length * 0.8:
            return truncated[:last_space] + "..."

        # 最后的选择：直接截断并添加省略号
        return truncated + "..."

    def _format_final_answer(
        self,
        structured_answer: Dict[str, Any],
        question: str,
        chunks: List[Dict[str, Any]]
    ) -> str:
        """
        格式化最终答案
        
        Args:
            structured_answer: 结构化答案
            question: 原始问题
            chunks: 检索块
            
        Returns:
            格式化后的答案
        """
        answer = structured_answer.get('answer', '')
        sources = structured_answer.get('sources', [])
        confidence = structured_answer.get('confidence', 0.0)
        
        # 构建最终答案
        final_parts = []
        
        # 主要答案
        if answer:
            final_parts.append(answer)
        
        # 添加来源信息
        if self.include_sources and sources:
            source_section = self._format_sources(sources)
            if source_section:
                final_parts.append("\n" + source_section)
        
        # 添加置信度信息（可选）
        if confidence < 0.5:
            final_parts.append("\n⚠️ 注意：基于当前检索结果，回答的可信度较低，建议进一步核实。")
        
        return "\n".join(final_parts)
    
    def _format_sources(self, sources: List[Dict[str, Any]]) -> str:
        """
        格式化来源信息
        
        Args:
            sources: 来源列表
            
        Returns:
            格式化后的来源信息
        """
        if not sources:
            return ""
        
        if self.citation_format == 'markdown':
            return self._format_sources_markdown(sources)
        elif self.citation_format == 'numbered':
            return self._format_sources_numbered(sources)
        else:
            return self._format_sources_simple(sources)
    
    def _format_sources_markdown(self, sources: List[Dict[str, Any]]) -> str:
        """Markdown格式的来源"""
        source_lines = ["## 参考来源"]
        
        for source in sources:
            source_name = source.get('source', 'unknown')
            page_num = source.get('page_num', 0)
            chunk_type = source.get('chunk_type', 'text')
            
            # 提取文件名
            if '/' in source_name or '\\' in source_name:
                file_name = source_name.split('/')[-1].split('\\')[-1]
            else:
                file_name = source_name
            
            # 构建来源行
            source_line = f"- **{file_name}**"
            if page_num > 0:
                source_line += f" (第{page_num}页)"
            if chunk_type != 'text':
                source_line += f" [{chunk_type}]"
            
            source_lines.append(source_line)
        
        return "\n".join(source_lines)
    
    def _format_sources_numbered(self, sources: List[Dict[str, Any]]) -> str:
        """编号格式的来源"""
        source_lines = ["参考来源："]
        
        for i, source in enumerate(sources, 1):
            source_name = source.get('source', 'unknown')
            page_num = source.get('page_num', 0)
            
            # 提取文件名
            if '/' in source_name or '\\' in source_name:
                file_name = source_name.split('/')[-1].split('\\')[-1]
            else:
                file_name = source_name
            
            source_line = f"{i}. {file_name}"
            if page_num > 0:
                source_line += f" (第{page_num}页)"
            
            source_lines.append(source_line)
        
        return "\n".join(source_lines)
    
    def _format_sources_simple(self, sources: List[Dict[str, Any]]) -> str:
        """简单格式的来源"""
        unique_sources = set()
        
        for source in sources:
            source_name = source.get('source', 'unknown')
            page_num = source.get('page_num', 0)
            
            # 提取文件名
            if '/' in source_name or '\\' in source_name:
                file_name = source_name.split('/')[-1].split('\\')[-1]
            else:
                file_name = source_name
            
            if page_num > 0:
                unique_sources.add(f"{file_name}(第{page_num}页)")
            else:
                unique_sources.add(file_name)
        
        if unique_sources:
            return f"来源：{', '.join(sorted(unique_sources))}"
        else:
            return ""
    
    def generate_summary(
        self,
        content_chunks: List[Dict[str, Any]],
        summary_type: str = "general"
    ) -> str:
        """
        生成内容总结
        
        Args:
            content_chunks: 内容块列表
            summary_type: 总结类型
            
        Returns:
            总结结果
        """
        if not content_chunks:
            return "没有内容可供总结。"
        
        # 合并内容
        all_content = []
        for chunk in content_chunks:
            content = chunk.get('content', '').strip()
            if content:
                all_content.append(content)
        
        combined_content = "\n\n".join(all_content)
        
        # 生成总结
        summary = self.multimodal_llm.summarize_content(
            content=combined_content,
            summary_type=summary_type,
            max_length=self.answer_max_length
        )
        
        return summary
    
    def extract_key_points(
        self,
        content_chunks: List[Dict[str, Any]]
    ) -> List[str]:
        """
        提取关键要点
        
        Args:
            content_chunks: 内容块列表
            
        Returns:
            关键要点列表
        """
        if not content_chunks:
            return []
        
        # 合并内容
        all_content = []
        for chunk in content_chunks:
            content = chunk.get('content', '').strip()
            if content:
                all_content.append(content)
        
        combined_content = "\n\n".join(all_content)
        
        # 提取要点
        key_points_text = self.multimodal_llm.summarize_content(
            content=combined_content,
            summary_type="key_points",
            max_length=self.answer_max_length
        )
        
        # 解析要点
        key_points = []
        lines = key_points_text.split('\n')
        
        for line in lines:
            line = line.strip()
            if line and (line.startswith('-') or line.startswith('•') or re.match(r'^\d+\.', line)):
                # 移除项目符号和编号
                point = re.sub(r'^[-•]\s*', '', line)
                point = re.sub(r'^\d+\.\s*', '', point)
                if point:
                    key_points.append(point)
        
        return key_points
